/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import QRCodeStyling, {
  DrawType,
  TypeNumber,
  Mode,
  ErrorCorrectionLevel,
  DotType,
  CornerSquareType,
  CornerDotType,
  Options
} from 'qr-code-styling';
import { ChevronDown, Download } from 'lucide-react';

// --- Components ---

const Accordion = ({ title, children, defaultOpen = false }: { title: string, children: React.ReactNode, defaultOpen?: boolean }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-gray-300 last:border-b-0">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-3 bg-[#e0e0e0] hover:bg-gray-300 transition-colors text-left text-sm font-normal text-gray-800"
      >
        <span>{title}</span>
        <span className="text-xs">{isOpen ? '+' : '+'}</span>
      </button>
      {isOpen && <div className="p-4 bg-[#f5f5f5] space-y-4">{children}</div>}
    </div>
  );
};

const InputGroup = ({ label, children }: { label: string, children: React.ReactNode }) => (
  <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
    <label className="w-20 text-sm text-gray-700 shrink-0">{label}</label>
    <div className="flex-1">{children}</div>
  </div>
);

// Logo SVG exato do modelo
const LOGO_SVG = `data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMDAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCAyMDAgODAiPjxyZWN0IHdpZHRoPSIyMDAiIGhlaWdodD0iODAiIGZpbGw9IndoaXRlIi8+PHRleHQgeD0iMTAiIHk9IjYwIiBmb250LWZhbWlseT0iSGVsdmV0aWNhLCBBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSI2MCIgZm9udC13ZWlnaHQ9IjkwMCIgZmlsbD0iYmxhY2siPlFSPC90ZXh0Pjx0ZXh0IHg9IjEwNSIgeT0iMzUiIGZvbnQtZmFtaWx5PSJIZWx2ZXRpY2EsIEFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjIyIiBmb250LXdlaWdodD0iNzAwIiBmaWxsPSJibGFjayI+Q09ERTwvdGV4dD48dGV4dCB4PSIxMDUiIHk9IjYwIiBmb250LWZhbWlseT0iSGVsdmV0aWNhLCBBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyMiIgZm9udC13ZWlnaHQ9IjcwMCIgZmlsbD0iYmxhY2siPlNUWUxJTkc8L3RleHQ+PC9zdmc+`;

type Extension = 'png' | 'jpeg' | 'webp' | 'svg';

export default function App() {
  const [options, setOptions] = useState<Options>({
    width: 300,
    height: 300,
    type: 'svg' as DrawType,
    data: 'https://qr-code-styling.com',
    image: LOGO_SVG,
    margin: 10,
    qrOptions: {
      typeNumber: 0 as TypeNumber,
      mode: 'Byte' as Mode,
      errorCorrectionLevel: 'Q' as ErrorCorrectionLevel
    },
    imageOptions: {
      hideBackgroundDots: true,
      imageSize: 0.5,
      margin: 2,
      crossOrigin: 'anonymous',
    },
    dotsOptions: {
      color: '#7b003c',
      type: 'rounded' as DotType
    },
    backgroundOptions: {
      color: '#ffffff',
    },
    cornersSquareOptions: {
      color: '#000000',
      type: 'extra-rounded' as CornerSquareType,
    },
    cornersDotOptions: {
      color: '#000000',
      type: 'dot' as CornerDotType,
    }
  });

  const [fileExtension, setFileExtension] = useState<Extension>('png');
  const qrRef = useRef<HTMLDivElement>(null);
  const qrCode = useRef<QRCodeStyling | null>(null);

  useEffect(() => {
    if (!qrCode.current) {
      qrCode.current = new QRCodeStyling(options);
    }
    if (qrRef.current) {
      qrRef.current.innerHTML = '';
      qrCode.current.append(qrRef.current);
    }
  }, []);

  useEffect(() => {
    if (qrCode.current) {
      qrCode.current.update(options);
    }
  }, [options]);

  const onDataChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setOptions(prev => ({ ...prev, data: e.target.value }));
  };

  const onImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setOptions(prev => ({ ...prev, image: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const onDownloadClick = () => {
    if (!qrCode.current) return;
    qrCode.current.download({ extension: fileExtension });
  };

  return (
    <div className="min-h-screen bg-gray-100 font-sans text-gray-900">
      {/* Header */}
      <header className="bg-[#333333] text-white h-14 flex items-center px-4 sm:px-20 justify-between sticky top-0 z-50">
        <div className="flex items-center gap-1">
          <span className="text-3xl font-bold tracking-tighter">QR</span>
          <div className="flex flex-col leading-[0.8] text-[10px] font-bold pt-1">
            <span>CODE</span>
            <span>STYLING</span>
          </div>
        </div>
        <div className="flex items-center gap-8 text-sm font-normal">
          <span>npm v1.8.3</span>
          <a href="https://github.com/denis660/qr-code-styling" target="_blank" rel="noreferrer" className="hover:text-gray-300">
            GitHub
          </a>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-[280px] flex flex-col justify-center px-4 sm:px-20 overflow-hidden">
        <div className="absolute inset-0 z-0" style={{ background: 'linear-gradient(90deg, #000000 0%, #7b003c 40%, #f3e5f5 100%)' }} />
        <div className="relative z-10 space-y-6">
          <h1 className="text-5xl font-bold text-white tracking-tight">QR Code Styling</h1>
          <div className="space-y-4">
            <p className="text-xl text-white opacity-90">An open source JS library</p>
            <p className="text-xl text-white opacity-90">For generating styled QR codes</p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded shadow-sm border border-gray-200 overflow-hidden">
            <Accordion title="Main Options" defaultOpen>
              <InputGroup label="Data">
                <textarea
                  value={options.data}
                  onChange={onDataChange}
                  className="w-full p-1.5 border border-gray-300 rounded-sm text-sm focus:ring-1 focus:ring-purple-500 focus:border-purple-500 outline-none min-h-[60px] bg-white"
                />
              </InputGroup>
              <InputGroup label="Image File">
                <div className="flex items-center gap-2">
                  <input
                    type="file"
                    onChange={onImageChange}
                    className="text-sm text-gray-500 file:mr-2 file:py-1.5 file:px-3 file:border file:border-gray-300 file:rounded-sm file:bg-[#f0f0f0] file:text-gray-800 hover:file:bg-gray-200 cursor-pointer"
                  />
                  {options.image && options.image !== LOGO_SVG && (
                    <button onClick={() => setOptions(prev => ({ ...prev, image: '' }))} className="bg-[#dcdcdc] hover:bg-gray-300 text-gray-800 px-3 py-1.5 text-sm transition-colors border border-gray-300 rounded-sm">
                      Cancel
                    </button>
                  )}
                </div>
              </InputGroup>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <InputGroup label="Width">
                  <input type="number" value={options.width} onChange={(e) => setOptions(prev => ({ ...prev, width: Number(e.target.value) }))} className="w-full p-1.5 border border-gray-300 rounded-sm text-sm bg-white" />
                </InputGroup>
                <InputGroup label="Height">
                  <input type="number" value={options.height} onChange={(e) => setOptions(prev => ({ ...prev, height: Number(e.target.value) }))} className="w-full p-1.5 border border-gray-300 rounded-sm text-sm bg-white" />
                </InputGroup>
              </div>
              <InputGroup label="Margin">
                <input type="number" value={options.margin} onChange={(e) => setOptions(prev => ({ ...prev, margin: Number(e.target.value) }))} className="w-[100px] p-1.5 border border-gray-300 rounded-sm text-sm bg-white" />
              </InputGroup>
            </Accordion>

            <Accordion title="Dots Options">
              <InputGroup label="Type">
                <select value={options.dotsOptions?.type} onChange={(e) => setOptions(prev => ({ ...prev, dotsOptions: { ...prev.dotsOptions, type: e.target.value as DotType } }))} className="w-full p-2 border border-gray-300 rounded text-sm">
                  {['square', 'dots', 'rounded', 'extra-rounded', 'classy', 'classy-rounded'].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </InputGroup>
              <InputGroup label="Color">
                <input type="color" value={options.dotsOptions?.color} onChange={(e) => setOptions(prev => ({ ...prev, dotsOptions: { ...prev.dotsOptions, color: e.target.value } }))} className="w-12 h-8 p-0 border-0 cursor-pointer" />
              </InputGroup>
            </Accordion>

            <Accordion title="Corners Square Options">
              <InputGroup label="Type">
                <select value={options.cornersSquareOptions?.type} onChange={(e) => setOptions(prev => ({ ...prev, cornersSquareOptions: { ...prev.cornersSquareOptions, type: e.target.value as CornerSquareType } }))} className="w-full p-2 border border-gray-300 rounded text-sm">
                  {['square', 'dot', 'extra-rounded'].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </InputGroup>
              <InputGroup label="Color">
                <input type="color" value={options.cornersSquareOptions?.color} onChange={(e) => setOptions(prev => ({ ...prev, cornersSquareOptions: { ...prev.cornersSquareOptions, color: e.target.value } }))} className="w-12 h-8 p-0 border-0 cursor-pointer" />
              </InputGroup>
            </Accordion>

            <Accordion title="Corners Dot Options">
              <InputGroup label="Type">
                <select value={options.cornersDotOptions?.type} onChange={(e) => setOptions(prev => ({ ...prev, cornersDotOptions: { ...prev.cornersDotOptions, type: e.target.value as CornerDotType } }))} className="w-full p-2 border border-gray-300 rounded text-sm">
                  {['square', 'dot'].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </InputGroup>
              <InputGroup label="Color">
                <input type="color" value={options.cornersDotOptions?.color} onChange={(e) => setOptions(prev => ({ ...prev, cornersDotOptions: { ...prev.cornersDotOptions, color: e.target.value } }))} className="w-12 h-8 p-0 border-0 cursor-pointer" />
              </InputGroup>
            </Accordion>

            <Accordion title="Background Options">
              <InputGroup label="Color">
                <input type="color" value={options.backgroundOptions?.color} onChange={(e) => setOptions(prev => ({ ...prev, backgroundOptions: { ...prev.backgroundOptions, color: e.target.value } }))} className="w-12 h-8 p-0 border-0 cursor-pointer" />
              </InputGroup>
            </Accordion>

            <Accordion title="Image Options">
              <InputGroup label="Hide Dots">
                <input type="checkbox" checked={options.imageOptions?.hideBackgroundDots} onChange={(e) => setOptions(prev => ({ ...prev, imageOptions: { ...prev.imageOptions, hideBackgroundDots: e.target.checked } }))} className="w-4 h-4" />
              </InputGroup>
              <InputGroup label="Size">
                <input type="range" min="0.1" max="1" step="0.1" value={options.imageOptions?.imageSize} onChange={(e) => setOptions(prev => ({ ...prev, imageOptions: { ...prev.imageOptions, imageSize: Number(e.target.value) } }))} className="w-full" />
              </InputGroup>
              <InputGroup label="Margin">
                <input type="number" value={options.imageOptions?.margin} onChange={(e) => setOptions(prev => ({ ...prev, imageOptions: { ...prev.imageOptions, margin: Number(e.target.value) } }))} className="w-full p-2 border border-gray-300 rounded text-sm" />
              </InputGroup>
            </Accordion>

            <Accordion title="QR Options">
              <InputGroup label="Type">
                <select value={options.type} onChange={(e) => setOptions(prev => ({ ...prev, type: e.target.value as DrawType }))} className="w-full p-2 border border-gray-300 rounded text-sm">
                  <option value="canvas">Canvas</option>
                  <option value="svg">SVG</option>
                </select>
              </InputGroup>
              <InputGroup label="Error Level">
                <select value={options.qrOptions?.errorCorrectionLevel} onChange={(e) => setOptions(prev => ({ ...prev, qrOptions: { ...prev.qrOptions, errorCorrectionLevel: e.target.value as ErrorCorrectionLevel } }))} className="w-full p-2 border border-gray-300 rounded text-sm">
                  {['L', 'M', 'Q', 'H'].map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </InputGroup>
            </Accordion>
          </div>

          <button 
            onClick={() => {
              const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(options, null, 2));
              const downloadAnchorNode = document.createElement('a');
              downloadAnchorNode.setAttribute("href", dataStr);
              downloadAnchorNode.setAttribute("download", "qr-options.json");
              document.body.appendChild(downloadAnchorNode);
              downloadAnchorNode.click();
              downloadAnchorNode.remove();
            }}
            className="bg-[#dcdcdc] hover:bg-gray-300 text-gray-800 px-4 py-2 text-sm transition-colors"
          >
            Export Options as JSON
          </button>

          <div className="pt-8 pb-4">
            <p className="text-xs text-gray-800">If you have any questions or issues please contact me via email or GitHub Issues.</p>
          </div>
        </div>

        <div className="lg:col-span-5 flex flex-col items-center lg:items-start gap-6">
          <div className="bg-white p-4 rounded shadow-md border border-gray-200 min-w-[332px] min-h-[332px] flex items-center justify-center">
            <div ref={qrRef} className="flex justify-center items-center" />
          </div>
          <div className="flex items-center">
            <button onClick={onDownloadClick} className="flex items-center gap-2 bg-[#dcdcdc] hover:bg-gray-300 text-gray-800 px-6 py-1.5 border-r border-gray-400 text-sm transition-colors">Download</button>
            <select value={fileExtension} onChange={(e) => setFileExtension(e.target.value as Extension)} className="bg-[#dcdcdc] hover:bg-gray-300 text-gray-800 px-3 py-1.5 text-sm outline-none transition-colors appearance-none cursor-pointer">
              <option value="png">PNG</option>
              <option value="jpeg">JPEG</option>
              <option value="webp">WEBP</option>
              <option value="svg">SVG</option>
            </select>
            <div className="bg-[#dcdcdc] px-2 py-1.5 pointer-events-none"><ChevronDown size={14} /></div>
          </div>
        </div>
      </main>

      <footer className="bg-[#212121] text-white py-4 px-4 sm:px-20 text-xs">
        <p>© 2024 Denys Kozak</p>
      </footer>
    </div>
  );
}
